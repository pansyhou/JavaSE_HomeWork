package Exp6;

import sun.net.idn.Punycode;

class Person {
    private String age;
    private String name;

    public  Person(String age,String name ) {
        this.age=age;
        this.name=name;

    }

    @Override
    public String toString() {
        return "Person{" +
                "age='" + age + '\'' +
                ", name='" + name + '\'' +
                '}';
    }

    public int hashCode() {
        return  name.hashCode();// 返回id属性的哈希值
    }

    public boolean equals(Person person) {
        return (this.age==person.age)&&(this.name==person.name);
    }
}
